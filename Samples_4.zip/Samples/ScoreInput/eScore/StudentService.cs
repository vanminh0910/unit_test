﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace eTicket
{
    class StudentService
    {
        private DbConnection dbConnection;
        public StudentService()
        {
            dbConnection = new DbConnection("localhost", "sa", "12345678", "test");
        }

        public static double ParseMathScore(string score)
        {
            //Math score is from 0 to 10
            double result;

            if (!double.TryParse(score, out result))
            {
                return -1;
            }

            if (((Convert.ToDouble(score) > 10))
               || (Convert.ToDouble(score) < 0))
            {
                return -1;
            }

            return result;
        }

        public static double ParseEnglishScore(string score)
        {
            //English score is from 0 to 5

            double result;

            if (!double.TryParse(score, out result))
            {
                return -1;
            }

            if (((Convert.ToDouble(score) > 5))
               || (Convert.ToDouble(score) < 0))
            {
                return -1;
            }

            return result;
        }

        private double CalculateAverage(double mathScore, double englishScore, bool inCity)
        {
            double average;

            if (!inCity)
            {
                average = (mathScore + englishScore + 1) / 2;
            }
            else
            {
                average = (mathScore + englishScore) / 2;
            }
            return average;
        }

        public bool SaveStudent(string id, string name, string math, string english, bool inCity)
        {
            double mathScore = ParseMathScore(math);
            double englishScore = ParseEnglishScore(english);

            if (mathScore == -1 || englishScore == -1)
            {
                MessageBox.Show("Error. Invalid Math or English score");
                return false;
            }

            double average = CalculateAverage(mathScore, englishScore, inCity);

            dbConnection.InsertStudent(id, name, mathScore, englishScore, inCity, average);

            return true;
        }
    }
}
