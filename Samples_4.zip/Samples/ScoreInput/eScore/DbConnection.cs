﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eTicket
{
    class DbConnection
    {
        // fields
        private string server;
        private string username;
        private string password;
        private string dbName;

        public DbConnection(string server, string username, string password, string dbName)
        {
            this.server = server;
            this.username = username;
            this.password = password;
            this.dbName = dbName;
            Console.WriteLine("Open connection to DB here");
        }

        public void InsertStudent(string id, string name, double math, double english, bool inCity, double average)
        {
            Console.WriteLine("Student record saved");
        }
    }
}
