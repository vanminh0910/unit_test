﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace eTicket
{
    public partial class ScoreForm : Form
    {
        public ScoreForm()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            StudentService studentService = new StudentService();
            if (studentService.SaveStudent(txtID.Text, txtName.Text, txtMath.Text, txtEnglish.Text, !rbtnCountry.Checked))
            {
                MessageBox.Show("Student record saved");
                return;
            }
        }
    }
}
