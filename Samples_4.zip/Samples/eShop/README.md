SportsStore
===========

Sports Store from [Pro ASP.NET MVC3 Framework](http://www.apress.com/9781430234043) (but for MVC5).

Working through this book to learn ASP.NET MVC. I'm using MVC5 instead of MVC3 like the book, and trying
figure out the differences as I go.

Differences
 - Using SASS instead of CSS
 - Using Bundles instead of straight CSS links
 - Using Nunit instead of Baked in VS Test.
