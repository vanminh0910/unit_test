﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Ninject;
using System.Web.Mvc;
using Moq;
using eShop.Domain.Abstract;
using eShop.Domain.Entities;
using eShop.Domain.Concrete;
using System.Configuration;
using eShop.WebUI.Infrastructure.Abstract;
using eShop.WebUI.Infrastructure.Concrete;

namespace eShop.WebUI.Infrastructure
{
    public class NinjectControllerFactory : DefaultControllerFactory
    {
        private IKernel ninjectKernel;

        public NinjectControllerFactory()
        {
            ninjectKernel = new StandardKernel();
            addBindings();
        }

        protected override IController GetControllerInstance(System.Web.Routing.RequestContext requestContext, Type controllerType)
        {
            return controllerType == null ? null : (IController)ninjectKernel.Get(controllerType);
        }
        private void addBindings()
        {
            ninjectKernel.Bind<IProductRepository>().To<EFProductRepository>();

            ninjectKernel.Bind<IOrderProcessor>().To<NullOrderProcessor>();

            ninjectKernel.Bind<IAuthProvider>().To<FormsAuthProvider>();
        }
    }
}