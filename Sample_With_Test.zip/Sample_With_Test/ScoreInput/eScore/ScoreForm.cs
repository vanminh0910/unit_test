﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace eTicket
{
    public partial class ScoreForm : Form
    {
        public ScoreForm()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            IDbConnection dbConnection = new DbConnection("localhost", "sa", "12345678", "test");
            StudentService studentService = new StudentService(dbConnection);
            Student student;

            double mathScore = Utils.ParseScore(txtMath.Text, 0, 10);

            if (mathScore == -1)
            {
                MessageBox.Show("Invalid math score. Please enter valid value from 0 to 10!");
                txtMath.Select();
                return;
            }

            double englishScore = Utils.ParseScore(txtEnglish.Text, 0, 5);

            if (englishScore == -1)
            {
                MessageBox.Show("Invalid English score. Please enter valid value from 0 to 10!");
                txtEnglish.Select();
                return;
            }

            if (rbtnCountry.Checked)
            {
                student = new CountryStudent();
            }
            else
            {
                student = new CityStudent();
            }

            student.ID = txtID.Text;
            student.Name = txtName.Text;
            student.Math = mathScore;
            student.English = englishScore;
            student.AverageScore = student.AvgCalculate();

            if (studentService.SaveStudent(student))
            {
                MessageBox.Show("Student record saved");
                return;
            }
            else
            {
                MessageBox.Show("Could not save student record. Something wrong happened");
                return;
            }
        }
    }
}
