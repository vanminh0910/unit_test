﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace eTicket
{
    class StudentService
    {
        private IDbConnection _dbConnection;
        public StudentService(IDbConnection dbConnection)
        {
            _dbConnection = dbConnection;
        }
        
        public bool SaveStudent(Student student)
        {
            return _dbConnection.InsertStudent(student);
        }
    }
}
