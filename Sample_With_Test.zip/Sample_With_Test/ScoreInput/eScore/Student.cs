﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eTicket
{
    public abstract class Student
    {
        // fields
        private string id;
        private string name;
        private double math;
        private double english;
        private double averageScore;
        private AREA area;
        
        // properties
        public string ID
        {
            get { return id; }
            set { id = value; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public double Math
        {
            get { return math; }
            set { math = value; }
        }

        public double English
        {
            get { return english; }
            set { english = value; }
        }

        public double AverageScore
        {
            get { return averageScore; }
            set { averageScore = value; }
        }

        public AREA Area
        {
            get { return area; }
            set { area = value; }
        }
        // methods
        public abstract double AvgCalculate();
    }

    public enum AREA
    {
        Country,
        City
    }
}

