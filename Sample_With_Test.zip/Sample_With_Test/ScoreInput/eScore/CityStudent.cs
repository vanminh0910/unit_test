﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eTicket
{
    public class CityStudent: Student
    {
        public override double AvgCalculate()
        {
            return (Math + English) / 2;
        }
    }
}
