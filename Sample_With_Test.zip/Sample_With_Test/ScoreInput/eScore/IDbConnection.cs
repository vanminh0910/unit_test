﻿namespace eTicket
{
    public interface IDbConnection
    {
        bool InsertStudent(Student student);
    }
}