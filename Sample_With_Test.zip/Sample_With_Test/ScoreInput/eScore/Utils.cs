﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eTicket
{
    public class Utils
    {
        public static double ParseScore(string score, double min, double max)
        {
            double result;

            if (!double.TryParse(score, out result))
            {
                return -1;
            }

            if (((Convert.ToDouble(score) > max))
               || (Convert.ToDouble(score) < min))
            {
                return -1;
            }

            return result;
        }
    }
}
