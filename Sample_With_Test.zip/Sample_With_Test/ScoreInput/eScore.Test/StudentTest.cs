﻿using eTicket;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eScore.Test
{
    [TestFixture]
    public class StudentTest
    {
        [Test]
        public void TestAverageScoreCalculationForCityStudent()
        {
            CityStudent cityStudent = new CityStudent();
            cityStudent.Math = 4.00;
            cityStudent.English = 3.00;
            cityStudent.AverageScore = cityStudent.AvgCalculate();
            double expectedAverageScore = 3.5;
            Assert.That(cityStudent.AverageScore, Is.EqualTo(expectedAverageScore));
        }

        [Test]
        public void TestAverageScoreCalculationForCountryStudent()
        {
            CountryStudent countryStudent = new CountryStudent();
            countryStudent.Math = 4.00;
            countryStudent.English = 3.00;
            countryStudent.AverageScore = countryStudent.AvgCalculate();
            double expectedAverageScore = 4;
            Assert.That(countryStudent.AverageScore, Is.EqualTo(expectedAverageScore));
        }

    }
}
