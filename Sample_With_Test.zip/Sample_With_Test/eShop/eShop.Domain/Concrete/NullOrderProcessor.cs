﻿using eShop.Domain.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eShop.Domain.Concrete
{
    public class NullOrderProcessor : IOrderProcessor
    {
        public void ProcessOrder(Entities.Cart cart, Entities.ShippingDetails details)
        {
            //noop
        }
    }
}
